"""
delegation.py — Delegation Boundary & Worker Port

The Core owns task/policy identity; this module is the narrow trust boundary to
specialist workers. Concrete routing/provider details stay behind DelegationBackend.
"""

from __future__ import annotations

import abc
import dataclasses
import hashlib
import json
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from .models import (
    AuditWorkItem,
    CredentialAccess,
    EgressDestination,
    Evidence,
    EvidenceValidity,
    ExecutionPolicy,
    ExecutionReceipt,
    FilesystemAccess,
    Provenance,
    NetworkAccess,
)
from .validators import validate_egress_policy


class DelegationStatus(str, Enum):
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    BLOCKED = "blocked"


@dataclasses.dataclass(frozen=True)
class DelegationRequest:
    """Normalized request payload sent across the worker boundary."""

    request_id: str
    work_item_ref: str
    target_surface: str
    auditor_name: str
    context_payload: Dict[str, Any]
    execution_policy: ExecutionPolicy
    task_policy: str

    @classmethod
    def from_work_item(
        cls,
        work_item: AuditWorkItem,
        context_payload: Dict[str, Any],
        *,
        task_policy: str,
    ) -> "DelegationRequest":
        if not task_policy:
            raise ValueError("task_policy is required; the Core must choose task policy explicitly.")
        return cls(
            request_id=str(uuid.uuid4()),
            work_item_ref=work_item.work_item_id,
            target_surface=work_item.target_surface,
            auditor_name=work_item.auditor,
            context_payload=dict(context_payload),
            execution_policy=work_item.effective_execution_policy,
            task_policy=task_policy,
        )


@dataclasses.dataclass(frozen=True)
class DelegationResult:
    """Normalized result received from the execution boundary."""

    request_id: str
    status: DelegationStatus
    output_payload: Optional[Dict[str, Any]]
    error_message: Optional[str]
    provider_info: Optional[str]
    usage_tokens: Optional[int]


class DelegationBackend(abc.ABC):
    """Abstract execution gateway. The default is fail-closed as external egress."""

    @property
    def egress_destination(self) -> EgressDestination:
        """Actual data boundary exercised by this backend."""
        return EgressDestination.APPROVED_EXTERNAL

    @abc.abstractmethod
    def delegate(self, request: DelegationRequest) -> DelegationResult:
        """Synchronously dispatch the request and await the result."""
        raise NotImplementedError


class WorkerPort:
    """Narrow Core → specialist-worker port with pre-dispatch safety enforcement."""

    def __init__(self, backend: DelegationBackend, actor_identity: str, task_policy: str):
        if not task_policy:
            raise ValueError("task_policy is required for WorkerPort configuration.")
        self.backend = backend
        self.actor_identity = actor_identity
        self.task_policy = task_policy

    def execute_delegation(
        self,
        work_item: AuditWorkItem,
        context_payload: Dict[str, Any],
        started_at: datetime,
        *,
        data_is_sensitive: Optional[bool] = None,
        target_snapshot_ref: Optional[str] = None,
    ) -> tuple[ExecutionReceipt, Optional[Evidence]]:
        """
        Enforce classification → egress policy before backend dispatch.

        Evidence is only emitted when a concrete target snapshot is supplied;
        the backend result is never persisted as canonical evidence itself.
        """
        actual_destination = self.backend.egress_destination
        egress_check = validate_egress_policy(
            work_item,
            data_is_sensitive=data_is_sensitive,
            actual_destination=actual_destination,
        )
        if egress_check.is_error:
            finished_at = datetime.now(timezone.utc)
            receipt = ExecutionReceipt(
                receipt_id=str(uuid.uuid4()),
                work_item_ref=work_item.work_item_id,
                command="omniroute-delegation",
                arguments=(work_item.work_item_id,),
                policy_snapshot=work_item.effective_execution_policy,
                started_at=started_at,
                finished_at=finished_at,
                exit_code=126,
                artifact_refs=(),
                environment_summary=f"WorkerPort: {self.actor_identity} | blocked: {egress_check.code}",
            )
            return receipt, None

        request = DelegationRequest.from_work_item(
            work_item,
            context_payload,
            task_policy=self.task_policy,
        )
        result = self.backend.delegate(request)
        finished_at = datetime.now(timezone.utc)

        if result.status == DelegationStatus.BLOCKED:
            exit_code = 126
        elif result.status == DelegationStatus.SUCCESS:
            exit_code = 0
        else:
            exit_code = 1

        receipt = ExecutionReceipt(
            receipt_id=str(uuid.uuid4()),
            work_item_ref=work_item.work_item_id,
            command="omniroute-delegation",
            arguments=(request.request_id,),
            policy_snapshot=work_item.effective_execution_policy,
            started_at=started_at,
            finished_at=finished_at,
            exit_code=exit_code,
            artifact_refs=(),
            environment_summary=(
                f"WorkerPort: {self.actor_identity} | status={result.status.value} | error={result.error_message}"
                if result.error_message
                else None
            ),
        )

        if result.status != DelegationStatus.SUCCESS or not isinstance(result.output_payload, dict):
            return receipt, None

        if not target_snapshot_ref:
            # Refuse to manufacture a canonical Evidence record without the immutable target identity.
            return receipt, None

        raw = json.dumps(result.output_payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        fingerprint = hashlib.sha256(raw).hexdigest()
        evidence = Evidence(
            evidence_id=str(uuid.uuid4()),
            target_snapshot_ref=target_snapshot_ref,
            work_item_ref=work_item.work_item_id,
            source_refs=(),
            dependencies=(),
            validity=EvidenceValidity.VALID,
            provenance=Provenance(actor=f"{self.actor_identity} via omniroute", generated_at=finished_at),
            fingerprint=fingerprint,
        )
        return receipt, evidence
