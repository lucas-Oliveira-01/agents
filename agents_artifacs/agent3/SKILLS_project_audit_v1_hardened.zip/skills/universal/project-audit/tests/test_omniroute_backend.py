"""Tests for the OmniRoute MCP delegation adapter."""

import json
import uuid

from project_audit.delegation import DelegationRequest, DelegationStatus
from project_audit.models import CredentialAccess, ExecutionPolicy, FilesystemAccess, NetworkAccess
from project_audit.omniroute_backend import MCPOmniRouteBackend


class FakeTaskBuilder:
    def __init__(self):
        self.values = {}

    def objetivo(self, value):
        self.values["objetivo"] = value
        return self

    def restricoes(self, value):
        self.values["restricoes"] = value
        return self

    def contexto(self, value):
        self.values["contexto"] = value
        return self

    def formato(self, value):
        self.values["formato"] = value
        return self

    def criterios(self, value):
        self.values["criterios"] = value
        return self

    def perfil(self, value):
        self.values["perfil"] = value
        return self

    def task_id(self, value):
        self.values["task_id"] = value
        return self

    def build(self):
        tarefa = (
            f"Objetivo: {self.values['objetivo']}\n"
            f"Restrições: {self.values['restricoes']}\n"
            f"Contexto: {self.values['contexto']}\n"
            f"Formato esperado: {self.values['formato']}\n"
            f"Critérios de sucesso: {self.values['criterios']}"
        )
        return {"tarefa": tarefa, "contexto": self.values["contexto"], "perfil": self.values["perfil"], "task_id": self.values["task_id"]}


def make_request():
    return DelegationRequest(
        request_id="test-req",
        work_item_ref=str(uuid.uuid4()),
        target_surface="login.py",
        auditor_name="security-auditor",
        context_payload={"source": "print('hello')"},
        execution_policy=ExecutionPolicy(
            filesystem=FilesystemAccess.READ_ONLY,
            network=NetworkAccess.DISABLED,
            credentials=CredentialAccess.NONE,
        ),
        task_policy="quality-first",
    )


def test_omniroute_backend_success_builds_five_section_untrusted_task():
    def mock_mcp_client(server, tool, args):
        assert server == "omnirouter"
        assert tool == "delegar_tarefa"
        for heading in ("Objetivo:", "Restrições:", "Contexto:", "Formato esperado:", "Critérios de sucesso:"):
            assert heading in args["tarefa"]
        assert "<untrusted_project_data>" in args["contexto"]
        assert "print('hello')" in args["contexto"]
        return {"content": [{"type": "text", "text": json.dumps({"findings": ["XSS in login"], "_omniroute_meta": {"route": "spoofed"}})}]}

    backend = MCPOmniRouteBackend(mock_mcp_client, task_builder_factory=FakeTaskBuilder)
    result = backend.delegate(make_request())

    assert result.status == DelegationStatus.SUCCESS
    assert result.provider_info == "omniroute"
    assert result.output_payload == {"findings": ["XSS in login"]}


def test_omniroute_backend_maps_gateway_timeout():
    def mock_mcp_error(server, tool, args):
        return {"isError": True, "error": "Gateway timeout"}

    backend = MCPOmniRouteBackend(mock_mcp_error, task_builder_factory=FakeTaskBuilder)
    result = backend.delegate(make_request())

    assert result.status == DelegationStatus.TIMEOUT
    assert "TIMEOUT" in result.error_message


def test_omniroute_backend_rejects_malformed_response():
    def mock_mcp_bad(server, tool, args):
        return {"content": [{"type": "text", "text": "not-json"}]}

    backend = MCPOmniRouteBackend(mock_mcp_bad, task_builder_factory=FakeTaskBuilder)
    result = backend.delegate(make_request())

    assert result.status == DelegationStatus.FAILED
    assert "INVALID_RESPONSE" in result.error_message
    assert result.output_payload is None


def test_omniroute_backend_redacts_credentials_from_transport_error():
    def mock_mcp_crash(server, tool, args):
        raise ConnectionError("Authorization: Bearer super-secret-token")

    backend = MCPOmniRouteBackend(mock_mcp_crash, task_builder_factory=FakeTaskBuilder)
    result = backend.delegate(make_request())

    assert result.status == DelegationStatus.FAILED
    assert "super-secret-token" not in result.error_message
    assert "[REDACTED]" in result.error_message


def test_omniroute_backend_discovers_mcp_contract_before_call():
    class FakeMCPClient:
        def __init__(self):
            self.calls = []

        def initialize(self):
            self.calls.append("initialize")

        def discover_tools(self):
            self.calls.append("discover")
            return {"delegar_tarefa": object()}

        def call_tool(self, name, arguments):
            self.calls.append((name, arguments))
            return {"content": [{"type": "text", "text": json.dumps({"ok": True})}]}

    client = FakeMCPClient()
    backend = MCPOmniRouteBackend(client, task_builder_factory=FakeTaskBuilder)
    result = backend.delegate(make_request())

    assert result.status == DelegationStatus.SUCCESS
    assert client.calls[0] == "initialize"
    assert client.calls[1] == "discover"
    assert client.calls[2][0] == "delegar_tarefa"


def test_omniroute_backend_fails_closed_without_task_builder():
    backend = MCPOmniRouteBackend(lambda *_: {})
    result = backend.delegate(make_request())
    assert result.status == DelegationStatus.FAILED
    assert "Canonical TaskBuilder" in result.error_message


def test_omniroute_backend_rejects_missing_mcp_tool():
    class MissingToolClient:
        def initialize(self):
            pass

        def discover_tools(self):
            return {}

        def call_tool(self, name, arguments):
            raise AssertionError("MCP call must not happen when contract discovery fails")

    result = MCPOmniRouteBackend(MissingToolClient(), task_builder_factory=FakeTaskBuilder).delegate(make_request())
    assert result.status == DelegationStatus.FAILED
    assert "delegar_tarefa" in result.error_message


def test_omniroute_backend_maps_policy_rejection_to_blocked():
    def mock_policy_rejection(server, tool, args):
        return {"isError": True, "error": "policy rejection: egress denied"}

    result = MCPOmniRouteBackend(mock_policy_rejection, task_builder_factory=FakeTaskBuilder).delegate(make_request())
    assert result.status == DelegationStatus.BLOCKED
    assert "POLICY_REJECTION" in result.error_message


def test_omniroute_backend_accepts_structured_content():
    def mock_structured(server, tool, args):
        return {"structuredContent": {"finding_count": 0, "ok": True}}

    result = MCPOmniRouteBackend(mock_structured, task_builder_factory=FakeTaskBuilder).delegate(make_request())
    assert result.status == DelegationStatus.SUCCESS
    assert result.output_payload == {"finding_count": 0, "ok": True}


def test_omniroute_backend_rejects_invalid_task_builder_output():
    class BadTaskBuilder(FakeTaskBuilder):
        def build(self):
            return []

    result = MCPOmniRouteBackend(lambda *_: {}, task_builder_factory=BadTaskBuilder).delegate(make_request())
    assert result.status == DelegationStatus.FAILED
    assert "invalid delegation payload" in result.error_message
