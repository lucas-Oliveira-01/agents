"""audit-normalize test suite."""
