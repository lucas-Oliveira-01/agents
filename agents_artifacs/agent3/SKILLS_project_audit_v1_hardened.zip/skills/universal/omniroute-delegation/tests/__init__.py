"""Test init."""
